const express = require('express');
const fs = require('fs');
const multer = require('multer');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

const dbFile = 'db.json';
let db = { users: [], files: [] };

if (fs.existsSync(dbFile)) {
    db = JSON.parse(fs.readFileSync(dbFile));
}

const saveDB = () => fs.writeFileSync(dbFile, JSON.stringify(db, null, 2));

// Multer setup
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage });

// Routes
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const user = db.users.find(u => u.username === username && u.password === password);
    if (user) return res.json({ success: true, user });
    res.status(401).json({ success: false, message: 'Invalid credentials' });
});

app.post('/api/register', (req, res) => {
    const { username, password } = req.body;
    if (db.users.find(u => u.username === username)) {
        return res.status(400).json({ success: false, message: 'User exists' });
    }
    db.users.push({ username, password });
    saveDB();
    res.json({ success: true });
});

app.get('/api/users', (req, res) => {
    res.json(db.users);
});

app.delete('/api/users/:username', (req, res) => {
    db.users = db.users.filter(u => u.username !== req.params.username);
    saveDB();
    res.json({ success: true });
});

app.post('/api/upload', upload.single('file'), (req, res) => {
    const file = req.file;
    db.files.push({ filename: file.filename, originalname: file.originalname });
    saveDB();
    res.json({ success: true, file });
});

app.get('/api/files', (req, res) => {
    res.json(db.files);
});

app.delete('/api/delete/:filename', (req, res) => {
    const filename = req.params.filename;
    db.files = db.files.filter(f => f.filename !== filename);
    saveDB();
    fs.unlink(`uploads/${filename}`, err => {
        if (err) return res.status(404).json({ success: false, message: 'File not found' });
        res.json({ success: true });
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});